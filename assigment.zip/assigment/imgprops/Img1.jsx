import React from 'react';

const Img1 = (props) => {
    return (
        <>        
        <img src={props.data} alt="" />
        </>

    );
}

export default Img1;
