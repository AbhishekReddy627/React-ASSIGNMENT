import React from 'react';
import Img1 from './img1';

import IMG from "./GT.webp"

const Img = () => {
    return (
        <>
        <Img1 data={IMG} />
        </>
    );
}

export default Img;
