import React from 'react';

const Q1 = (props) => {
    return (
        <>
        <h1>{props.data} {props.name}</h1>
        </>
    );
}
export default Q1;
